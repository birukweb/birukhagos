import Image from "next/image"
import Link from "next/link"
import AnimatedBackground from "@/components/animated-background"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white px-4 py-8 relative overflow-hidden">
      <AnimatedBackground />

      <div className="max-w-md w-full flex flex-col items-center z-10">
        {/* Profile Image */}
        <div className="w-24 h-24 md:w-28 md:h-28 rounded-full overflow-hidden mb-3 border-2 border-zinc-800 hover:border-zinc-600 transition-all duration-300 transform hover:scale-105">
          <Image src="/profile.jpg" alt="Biruk Hagos" width={112} height={112} className="object-cover w-full h-full" />
        </div>

        {/* Name */}
        <h1 className="text-lg font-normal text-gray-300 mb-4 tracking-wide">Biruk Hagos</h1>

        {/* Tagline */}
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8 leading-tight tracking-tight">
          I&apos;m a wantrepreneur with big dreams, running YouTube channels.
        </h2>

        {/* Social Links */}
        <div className="flex gap-3 mb-8 justify-center">
          <Link
            href="https://x.com/realbirruk"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 transition-all duration-300 px-4 py-2 rounded-full hover:shadow-lg hover:shadow-zinc-900/20 transform hover:-translate-y-1"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="currentColor">
              <g>
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path>
              </g>
            </svg>
            <span>@realbirruk</span>
          </Link>
          <Link
            href="https://www.youtube.com/channel/UCQtp_KttCoUzzL3UZz8_KEw"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 transition-all duration-300 px-4 py-2 rounded-full hover:shadow-lg hover:shadow-zinc-900/20 transform hover:-translate-y-1"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="currentColor">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
            <span>@realbirruk</span>
          </Link>
        </div>

        {/* Cards */}
        <div className="w-full space-y-4">
          {/* Discord Card */}
          <div className="w-full bg-zinc-900/80 backdrop-blur-sm rounded-lg p-4 flex items-center hover:bg-zinc-800/90 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg hover:shadow-indigo-900/20">
            <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center mr-4 transition-transform duration-300 group-hover:scale-110">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"></path>
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="font-bold tracking-wide">Discord Community</h3>
              <p className="text-sm text-gray-400">
                Join my free Discord community filled with awesome people who are driven to succeed!
              </p>
            </div>
            <Link
              href="https://discord.gg/RSmAcDMsQK"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-zinc-800 hover:bg-indigo-600 transition-all duration-300 px-4 py-2 rounded text-sm font-medium hover:shadow-md transform hover:-translate-y-1"
            >
              Join
            </Link>
          </div>

          {/* Newsletter Card */}
          <div className="w-full bg-zinc-900/80 backdrop-blur-sm rounded-lg p-4 flex items-center hover:bg-zinc-800/90 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg hover:shadow-red-900/20">
            <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center mr-4 transition-transform duration-300 group-hover:scale-110">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg>
            </div>
            <div className="flex-1">
              <h3 className="font-bold tracking-wide">Newsletter</h3>
              <p className="text-sm text-gray-400">Subscribe to my newsletter for updates</p>
            </div>
            <Link
              href="https://smarttube-newsletter.beehiiv.com/subscribe"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-zinc-800 hover:bg-red-600 transition-all duration-300 px-4 py-2 rounded text-sm font-medium hover:shadow-md transform hover:-translate-y-1"
            >
              Subscribe
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 text-sm text-gray-500 z-10">© {new Date().getFullYear()} Biruk Hagos</footer>
    </div>
  )
}
